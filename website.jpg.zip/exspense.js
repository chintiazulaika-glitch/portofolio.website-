// =========================
// FILE: expense.js
// =========================

let expenses = JSON.parse(localStorage.getItem("expenses")) || [];

function saveExpense() {
    localStorage.setItem("expenses", JSON.stringify(expenses));
}

function renderExpense() {

    const list = document.getElementById("expense-list");
    const total = document.getElementById("total");

    list.innerHTML = "";

    let totalAmount = 0;

    expenses.forEach((expense, index) => {

        totalAmount += expense.amount;

        list.innerHTML += `
      <li>
        ${expense.title} - Rp ${expense.amount}
        <button onclick="deleteExpense(${index})">Hapus</button>
      </li>
    `;
    });

    total.innerText = totalAmount;
}

function addExpense() {

    const title = document.getElementById("title").value;
    const amount = document.getElementById("amount").value;

    if (title === "" || amount === "") {
        alert("Isi semua data!");
        return;
    }

    expenses.push({
        title: title,
        amount: Number(amount)
    });

    saveExpense();
    renderExpense();

    document.getElementById("title").value = "";
    document.getElementById("amount").value = "";
}

function deleteExpense(index) {
    expenses.splice(index, 1);

    saveExpense();
    renderExpense();
}

renderExpense();