// =========================
// FILE: todo.js
// =========================

let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

function saveTask() {
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function renderTask(filter = "all") {

    const taskList = document.getElementById("taskList");

    taskList.innerHTML = "";

    tasks.forEach((task, index) => {

        if (filter === "completed" && !task.completed) return;
        if (filter === "pending" && task.completed) return;

        taskList.innerHTML += `
      <li class="${task.completed ? 'completed' : ''}">
        ${task.text}

        <div>
          <button onclick="completeTask(${index})">✔</button>
          <button onclick="deleteTask(${index})">X</button>
        </div>
      </li>
    `;
    });
}

function addTask() {

    const input = document.getElementById("taskInput");

    if (input.value === "") {
        alert("Masukkan tugas!");
        return;
    }

    tasks.push({
        text: input.value,
        completed: false
    });

    saveTask();
    renderTask();

    input.value = "";
}

function completeTask(index) {

    tasks[index].completed = !tasks[index].completed;

    saveTask();
    renderTask();
}

function deleteTask(index) {

    tasks.splice(index, 1);

    saveTask();
    renderTask();
}

function filterTask(status) {
    renderTask(status);
}

renderTask();